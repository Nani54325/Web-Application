<?php
session_start();

$eve_id=$_SESSION['eve_id'];
$eve_name=$_SESSION['eve_name'];
$eve_fee=$_SESSION['eve_fee'];
$tickets=$_SESSION['tickets'];
$reg_num=$_SESSION['reg_num'];
$total=$_SESSION['total'];
?>





<!DOCTYPE html>
<html>
<head>
	<title>payment</title>
	<script type="text/javascript">
		window.onload = function() {
    if(!window.location.hash) {
        window.location = window.location + '#loaded';
        window.location.reload();
    }
}
	</script>

<style type="text/css">
	.main{
		width:50%;
		padding:5%;
		text-align: center;
		margin-left: 19%;
		margin-top: 7%;
		border: 2px solid black;
		border-radius: 9px;
		background-color: white;
	}
	}
</style>


</head>
<body>
<div class="main">
	Event ID:&emsp;&emsp;<?php echo $eve_id;?><br>
	Event Name:&emsp;&emsp;<?php echo $eve_name;?><br>
	Event Fee:&emsp;&emsp;<?php echo $eve_fee;?><br>
	Number Of Tickets:&emsp;&emsp;<?php echo $tickets;?><br>
    Registration Number:&emsp;&emsp;<?php echo $reg_num;?><br>
	total:&emsp;&emsp;<?php echo $total;?><br>
</div>
</body>
</html>